#!/bin/sh
eval `dbus export merlinclash_`
source /koolshare/scripts/base.sh


if [ "$merlinclash_enable" == "1" ];then
	echo 关闭clash插件！
	sh /koolshare/merlinclash/clashconfig.sh stop
    sleep 1
fi


find /koolshare/init.d/ -name "*clash*" | xargs rm -rf
rm -rf /koolshare/bin/clash
rm -rf /koolshare/bin/yq
rm -rf /koolshare/bin/jq_c
#------网易云内容-----------
rm -rf //koolshare/bin/UnblockNeteaseMusic
rm -rf //koolshare/bin/Music
#------网易云内容-----------
rm -rf /tmp/upload/yamls.txt

rm -rf /koolshare/res/icon-merlinclash.png
rm -rf /koolshare/res/clash-dingyue.png
rm -rf /koolshare/res/clash-kcp.jpg
rm -rf /koolshare/res/merlinclash.css
rm -rf /koolshare/res/mc-tablednd.js
rm -rf /koolshare/res/mc-menu.js
rm -rf /koolshare/merlinclash/Country.mmdb
rm -rf /koolshare/merlinclash/clashconfig.sh
rm -rf /koolshare/merlinclash/yaml_bak/*
rm -rf /koolshare/merlinclash/yaml_use/*
rm -rf /koolshare/merlinclash/yaml_basic/*
rm -rf /koolshare/merlinclash/yaml_dns/*

rm -rf /koolshare/merlinclash/dashboard/*
rm -rf /koolshare/scripts/clash*.sh
rm -rf /koolshare/scripts/openssl.cnf
rm -rf /koolshare/webs/Module_merlinclash.asp
rm -rf /koolshare/merlinclash
rm -f /koolshare/scripts/merlinclash_install.sh
rm -f /koolshare/scripts/uninstall_merlinclash.sh
rm -rf /tmp/upload/*_status.txt
rm -rf /tmp/upload/merlinclash*
rm -rf /tmp/upload/dlercloud.log
rm -rf /tmp/dc*


ipset flush music
ipset destroy music

dbus remove merlinclash_proxygroup_version
dbus remove merlinclash_proxygame_version

dbus remove softcenter_module_merlinclash_install
dbus remove softcenter_module_merlinclash_version
dbus remove merlinclash_version_local
dbus remove merlinclash_patch_version
dbus remove merlinclash_dashboard_secret
dbus remove merlinclash_dc_ss
dbus remove merlinclash_dc_v2
dbus remove merlinclash_dc_trojan
dbus remove merlinclash_links
dbus remove merlinclash_links2
dbus remove merlinclash_kcp_param_2
dbus remove merlinclash_dc_name
dbus remove merlinclash_dc_passwd
dbus remove merlinclash_dc_token